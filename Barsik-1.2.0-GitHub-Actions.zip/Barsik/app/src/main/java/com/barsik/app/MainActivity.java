package com.barsik.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.format.Formatter;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(246, 247, 249);
    private static final int CARD = Color.WHITE;
    private static final int TEXT = Color.rgb(18, 24, 38);
    private static final int MUTED = Color.rgb(119, 129, 150);
    private static final int ACC = Color.rgb(20, 146, 255);
    private static final int GREEN = Color.rgb(20, 180, 108);
    private static final int ORANGE = Color.rgb(245, 158, 11);
    private static final int RED = Color.rgb(232, 72, 72);

    private LinearLayout root, content, nav;
    private TextView title, subtitle;
    private int page = 0;
    private final Handler handler = new Handler();
    private final ExecutorService executor = Executors.newCachedThreadPool();
    private long lastPing = -1;
    private boolean online = false;
    private String lastCheck = "Ещё не проверяли";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        build();
        requestWifiPermissionIfNeeded();
    }

    private void requestWifiPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 7);
        }
    }

    private TextView tv(String s, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setIncludeFontPadding(true);
        return t;
    }
    private GradientDrawable bg(int color, float radius) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }
    private TextView button(String s) {
        TextView t = tv(s, 15, Color.WHITE); t.setGravity(Gravity.CENTER); t.setTypeface(null, 1);
        t.setBackground(bg(ACC, 34)); t.setPadding(18, 12, 18, 12); return t;
    }
    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(20,18,20,18);
        l.setBackground(bg(CARD, 26)); l.setElevation(1.5f);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,12); l.setLayoutParams(p); return l;
    }
    private void build() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG); setContentView(root);
        LinearLayout head = new LinearLayout(this); head.setOrientation(LinearLayout.VERTICAL); head.setPadding(24,18,24,6);
        LinearLayout brand = new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.ic_barsik); brand.addView(logo, new LinearLayout.LayoutParams(40,40));
        TextView name = tv("Barsik", 24, TEXT); name.setTypeface(null,1); name.setPadding(12,0,0,0); brand.addView(name); head.addView(brand);
        title = tv("Сеть под контролем", 28, TEXT); title.setTypeface(null,1); head.addView(title);
        subtitle = tv("Локальная диагностика роутера", 14, MUTED); subtitle.setPadding(0,4,0,8); head.addView(subtitle); root.addView(head);

        ScrollView scroll = new ScrollView(this); content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(20,8,20,100); scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        nav = new LinearLayout(this); nav.setPadding(8,7,8,8); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(CARD); root.addView(nav,new LinearLayout.LayoutParams(-1,70));
        String[] names = {"Главная","Сеть","Устройства","Настройки"};
        for(int i=0;i<4;i++){ final int x=i; TextView n=tv(names[i],12,MUTED); n.setGravity(Gravity.CENTER); n.setOnClickListener(v->{page=x;render();}); nav.addView(n,new LinearLayout.LayoutParams(0,-1,1)); }
        render();
    }
    private void render(){ content.removeAllViews(); if(page==0) home(); else if(page==1) network(); else if(page==2) devices(); else settings(); }
    private void header(String a,String b){ title.setText(a); subtitle.setText(b); }
    private void label(LinearLayout c,String a,String b){ TextView x=tv(a,12,MUTED); c.addView(x); TextView y=tv(b,18,TEXT); y.setTypeface(null,1); y.setPadding(0,3,0,10); c.addView(y); }
    private void home(){
        header("Сеть под контролем", "Всё важное — на одном экране");
        LinearLayout status=card(); LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView dot=tv("●",26, online?GREEN:ORANGE); row.addView(dot); LinearLayout col=new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setPadding(12,0,0,0);
        TextView a=tv(online?"Интернет работает":"Проверка не выполнена",19,TEXT); a.setTypeface(null,1); col.addView(a); col.addView(tv(lastCheck,13,MUTED)); row.addView(col,new LinearLayout.LayoutParams(0,-2,1));
        status.addView(row); content.addView(status);

        LinearLayout metrics=new LinearLayout(this); metrics.setOrientation(LinearLayout.HORIZONTAL);
        metric(metrics,"PING", lastPing>=0?lastPing+" мс":"—"); metric(metrics,"СЕТЬ", transport()); metric(metrics,"IP", localIp()); content.addView(metrics);

        LinearLayout router=card(); label(router,"Шлюз",gateway()); label(router,"Подключение",transport()); label(router,"Интернет",online?"Доступен":"Не проверен"); content.addView(router);
        TextView b=button("Проверить соединение"); b.setOnClickListener(v->runDiagnostics()); content.addView(b,new LinearLayout.LayoutParams(-1,54));
    }
    private void metric(LinearLayout p,String a,String b){ LinearLayout c=card(); c.setPadding(15,14,15,14); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(0,0,7,0); c.setLayoutParams(lp); c.addView(tv(a,10,MUTED)); TextView z=tv(b,15,TEXT); z.setTypeface(null,1); z.setPadding(0,4,0,0); c.addView(z); p.addView(c); }

    private void network(){
        header("Диагностика","Проверяем Wi‑Fi, шлюз и интернет");
        LinearLayout result=card(); TextView icon=tv(online?"✓":"○",56,online?GREEN:ORANGE); icon.setGravity(Gravity.CENTER); result.addView(icon,new LinearLayout.LayoutParams(-1,78));
        TextView state=tv(online?"Соединение в порядке":"Запустите проверку",20,TEXT); state.setGravity(Gravity.CENTER); state.setTypeface(null,1); result.addView(state);
        TextView desc=tv("Проверка выполняется локально и не требует аккаунта Barsik.",13,MUTED); desc.setGravity(Gravity.CENTER); desc.setPadding(0,5,0,18); result.addView(desc);
        TextView b=button("Запустить полную проверку"); b.setOnClickListener(v->runDiagnostics()); result.addView(b,new LinearLayout.LayoutParams(-1,54)); content.addView(result);
        LinearLayout checks=card(); checkRow(checks,"Роутер / шлюз",gateway().equals("не определён")?false:true); checkRow(checks,"DNS / интернет",online); checkRow(checks,"Транспорт",!transport().equals("Неизвестно")); checkRow(checks,"Локальный IP",!localIp().equals("не определён")); content.addView(checks);
        TextView tip=tv("Совет: если Wi‑Fi есть, но интернет пропал, Barsik поможет отделить проблему роутера от проблемы внешней сети.",13,MUTED); tip.setPadding(4,4,4,0); content.addView(tip);
    }
    private void checkRow(LinearLayout c,String name,boolean ok){ LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); TextView n=tv(name,15,TEXT); r.addView(n,new LinearLayout.LayoutParams(0,42,1)); TextView s=tv(ok?"✓":"—",18,ok?GREEN:MUTED); r.addView(s); c.addView(r); }

    private void devices(){
        header("Устройства","Кто виден в локальной сети");
        LinearLayout c=card(); label(c,"Это устройство",Build.MODEL); label(c,"Локальный IP",localIp()); label(c,"Шлюз",gateway()); content.addView(c);
        LinearLayout arp=card(); TextView h=tv("Найденные клиенты",17,TEXT); h.setTypeface(null,1); arp.addView(h); List<String> clients=readArp();
        if(clients.isEmpty()) { TextView empty=tv("Пока виден только этот телефон. Некоторые роутеры скрывают список клиентов.",13,MUTED); empty.setPadding(0,7,0,0); arp.addView(empty); }
        else for(String s:clients){ TextView x=tv(s,14,TEXT); x.setPadding(0,12,0,0); arp.addView(x); }
        content.addView(arp);
    }
    private List<String> readArp(){ List<String> out=new ArrayList<>(); try(BufferedReader br=new BufferedReader(new FileReader("/proc/net/arp"))){ String line; br.readLine(); while((line=br.readLine())!=null){ String[] p=line.trim().split("\\s+"); if(p.length>=6 && !p[3].equals("00:00:00:00:00:00")) out.add(p[0]+"  ·  "+p[3].toUpperCase(Locale.US)); }}catch(Exception ignored){} return out; }

    private void settings(){
        header("Настройки","Barsik работает локально");
        LinearLayout wifi=card(); TextView h=tv("Wi‑Fi рядом",17,TEXT); h.setTypeface(null,1); wifi.addView(h); TextView d=tv("Сканировать доступные сети и показать каналы.",13,MUTED); d.setPadding(0,5,0,12); wifi.addView(d);
        TextView scan=button("Сканировать Wi‑Fi"); scan.setOnClickListener(v->scanWifi()); wifi.addView(scan,new LinearLayout.LayoutParams(-1,52)); content.addView(wifi);
        LinearLayout about=card(); label(about,"Версия","1.2.0"); label(about,"Режим","Только локальная диагностика"); label(about,"Данные","Не отправляются в облако"); content.addView(about);
    }
    private void scanWifi(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestWifiPermissionIfNeeded(); Toast.makeText(this,"Разрешите доступ к геоданным для сканирования Wi‑Fi",Toast.LENGTH_LONG).show(); return;}
        WifiManager wm=(WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE); if(wm==null){return;} boolean started=wm.startScan();
        if(!started) Toast.makeText(this,"Сканирование занято или ограничено системой",Toast.LENGTH_LONG).show();
        handler.postDelayed(()->showWifiResults(wm.getScanResults()),1800);
    }
    private void showWifiResults(List<ScanResult> results){
        LinearLayout box=card(); TextView h=tv("Wi‑Fi сети",18,TEXT); h.setTypeface(null,1); box.addView(h);
        if(results==null||results.isEmpty()){box.addView(tv("Сети не найдены. Попробуйте ещё раз.",13,MUTED));}
        else { Collections.sort(results, Comparator.comparingInt((ScanResult r)->r.level).reversed()); int count=Math.min(results.size(),12); for(int i=0;i<count;i++){ScanResult r=results.get(i); String ssid=(r.SSID==null||r.SSID.isEmpty())?"Скрытая сеть":r.SSID; String band=r.frequency>=5000?"5 ГГц":"2.4 ГГц"; TextView row=tv(ssid+"\n"+band+" · канал "+channel(r.frequency)+" · "+r.level+" dBm",14,TEXT); row.setPadding(0,10,0,3); box.addView(row);} }
        content.addView(box,0); Toast.makeText(this,"Готово",Toast.LENGTH_SHORT).show();
    }
    private int channel(int f){ if(f>=2412&&f<=2484)return (f-2407)/5; if(f>=5000&&f<=5900)return (f-5000)/5; return 0; }

    private void runDiagnostics(){
        Toast.makeText(this,"Проверяем соединение…",Toast.LENGTH_SHORT).show();
        executor.execute(()->{
            long start=System.currentTimeMillis(); boolean gatewayOk=false; long p=-1;
            try{String g=gateway(); if(!g.equals("не определён")){long t=System.currentTimeMillis(); gatewayOk=InetAddress.getByName(g).isReachable(1200); if(gatewayOk)p=System.currentTimeMillis()-t;}}catch(Exception ignored){}
            boolean web=false; try{HttpURLConnection c=(HttpURLConnection)new URL("https://connectivitycheck.gstatic.com/generate_204").openConnection(); c.setConnectTimeout(2500); c.setReadTimeout(2500); c.setInstanceFollowRedirects(false); c.connect(); web=c.getResponseCode()>=200&&c.getResponseCode()<400; c.disconnect();}catch(Exception ignored){}
            final long fp=p; final boolean fweb=web; runOnUiThread(()->{lastPing=fp; online=fweb; lastCheck="Проверено только что · "+(System.currentTimeMillis()-start)+" мс"; page=1; render(); Toast.makeText(this,fweb?"Интернет доступен":"Интернет недоступен",Toast.LENGTH_LONG).show();});
        });
    }
    private boolean hasActive(){ try{ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE); Network n=cm.getActiveNetwork(); return n!=null&&cm.getNetworkCapabilities(n)!=null;}catch(Exception e){return false;} }
    private String gateway(){ try{ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE); Network n=cm.getActiveNetwork(); LinkProperties lp=cm.getLinkProperties(n); if(lp!=null) for(android.net.RouteInfo r:lp.getRoutes()) if(r.getGateway()!=null) return r.getGateway().getHostAddress(); }catch(Exception ignored){} return "не определён"; }
    private String transport(){ try{ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE); Network n=cm.getActiveNetwork(); NetworkCapabilities c=cm.getNetworkCapabilities(n); if(c!=null){if(c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI))return "Wi‑Fi";if(c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))return "Мобильная сеть";if(c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))return "Ethernet";}}catch(Exception ignored){} return "Неизвестно"; }
    private String localIp(){ try{WifiManager wm=(WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE); WifiInfo wi=wm.getConnectionInfo(); if(wi!=null&&wi.getIpAddress()!=0)return Formatter.formatIpAddress(wi.getIpAddress());}catch(Exception ignored){} return "не определён"; }
    @Override protected void onDestroy(){super.onDestroy();executor.shutdownNow();}
}
